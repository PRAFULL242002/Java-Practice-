package com.demo.service;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.demo.beans.Course;
import com.demo.dao.CourseDao;
import com.demo.dao.CourseDaoImpl;

public class CourseServiceImpl implements CourseService{
	private CourseDao cdao;
	public CourseServiceImpl()
	{
		cdao = new CourseDaoImpl();
	}
	
	@Override
	public boolean addnewcourse() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name of Course: ");
		String cname = sc.next();
		System.out.println("Enter Fees: ");
		double fees = sc.nextDouble();
		System.out.println("Enter Course Duration: ");
		int duration = sc.nextInt();
		System.out.println("Enter Capacity: ");
		int capacity = sc.nextInt();
		Course c = new Course(cname, fees, duration, capacity);
		return cdao.save(c);
	}
	
	public Map<String, Course> getAll() 
	{
		return cdao.findAll();
	}

	@Override
	public boolean deletebyname(String delcourse) {
		return cdao.removeByName(delcourse);
	}

	@Override
	public boolean updatebyname(String updacourse, int ncapacity, int nduration) {
		return cdao.updatebyname(updacourse, ncapacity, nduration);
	}

	@Override
	public List<Course> getByName(String nm) {
		// TODO Auto-generated method stub
		return null;
	}




}
