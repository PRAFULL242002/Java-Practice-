package com.demo.service;

import java.util.List;
import java.util.Map;

import com.demo.beans.Course;

public interface CourseService {
	boolean addnewcourse();
	
	Map<String, Course> getAll();

	boolean deletebyname(String delcourse);

	boolean updatebyname(String updacourse, int ncapacity, int nduration);

	List<Course> getByName(String nm);


}
