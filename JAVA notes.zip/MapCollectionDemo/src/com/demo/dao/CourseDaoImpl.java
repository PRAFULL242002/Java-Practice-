package com.demo.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.demo.beans.Course;

public class CourseDaoImpl implements CourseDao{
	
	static Map<String, Course> hm;
	static {
		hm = new HashMap();
		hm.put("DAC", new Course("DAC",10000.00,200,150));
		hm.put("DBDA", new Course("DBDA",15000.00,150,100));
	}
	

	@Override
	public boolean save(Course c) {
		Course c1= hm.putIfAbsent(c.getCname(), c);
		if(c1 != null)
		{
			return true;
		}
		return false;
	}
	
	public Map<String, Course> findAll() 
	{	
		return hm;
	}

	@Override
	public boolean removeByName(String delcourse) {
		Course c1 = hm.remove(delcourse);
		if(c1!=null)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean updatebyname(String updacourse, int ncapacity, int nduration) {
		Course c = hm.get(updacourse);
		if(c!=null)
		{
			c.setCapacity(ncapacity);
			c.setDuration(nduration);
			return true;
		}
		return false;
	}

	@Override
	public List<Course> getByName(String nm) {
		// TODO Auto-generated method stub
		return null;
	}




	
}
