package com.demo.dao;

import java.util.List;

import com.demo.beans.Course;

public interface CourseDao {

	boolean save(Course c);

	java.util.Map<String, Course> findAll();


	boolean removeByName(String delcourse);

	boolean updatebyname(String updacourse, int ncapacity, int nduration);

	List<Course> getByName(String nm);


}
