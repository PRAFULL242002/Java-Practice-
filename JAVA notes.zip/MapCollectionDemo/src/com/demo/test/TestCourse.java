package com.demo.test;

import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.demo.beans.Course;
import com.demo.service.CourseService;
import com.demo.service.CourseServiceImpl;

public class TestCourse {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		CourseService cservice = new CourseServiceImpl();
		int choice = 0;
		do {
			System.out.print("1. Add New Course \n2. Delete Course \n3. Update Course \n4. Display All");
			System.out.println("5. Display by Name \n6. Display based on Duration \n7. display in sorted order of course name\\n8. display in sorted order of duration\\n9.exit\\nchoice:");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1 ->{
				boolean ans = cservice.addnewcourse();
				if(ans)
				{
					System.out.println("Added Successfully");
				}
				else
				{
					System.out.println("Not Found");
				}
			}
			case 2 ->{
				System.out.println("Enter Course Name to Delete");
				String delcourse = sc.next();
				boolean status = cservice.deletebyname(delcourse);
				if(status)
				{
					System.out.println("Course Deleted");
				}
				else
				{
					System.out.println("Not Found");
				}
			}
			case 3 ->{
				System.out.println("Enter Course name for Update");
				String updacourse = sc.next();
				System.out.println("Enter new Capacity: ");
				int ncapacity = sc.nextInt();
				System.out.println("Enter new Duration");
				int nduration = sc.nextInt();
				boolean upcourse = cservice.updatebyname(updacourse, ncapacity, nduration);
				if(upcourse)
				{
					System.out.println("Updated Successfully");
				}
				else
				{
					System.out.println("Not Found");
				}
			}
			case 4 ->{
				Map<String,Course> hm1=cservice.getAll();
				Set<String> s=hm1.keySet();
				s.stream().forEach(ob->System.out.println(ob+"------->"+hm1.get(ob)));
			}
			case 5 ->{
				System.out.println("Enter Name for Display: ");
				String nm = sc.next();
				List<Course> lst = cservice.getByName(nm);
				if(lst != null)
				{
					lst.forEach(System.out::println);
				}
				else
				{
					System.out.println("Not Found");
				}
				
			}
			case 6 ->{}
			case 7 ->{}
			case 8 ->{}
			case 9 ->{}
			}
		}while(choice != 9);

	}

}
