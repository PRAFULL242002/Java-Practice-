
import './App.css';
import { FunScorecard } from './FunScorecard/FunScorecard';

function App() {
  return (
    <div className="App">
     <FunScorecard/>
    </div>
  );
}

export default App;
