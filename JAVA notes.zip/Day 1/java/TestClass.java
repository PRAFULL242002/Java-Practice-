class TestClass{
  public static void main(String[] args){
     System.out.println("This is testing classpath");
  }
}