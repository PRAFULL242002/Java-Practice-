
//Accept 3 numbers from command line arguments. If number is prime, then print the table of 
//the number. Other wise divide number by 10 and display output

public class Primee {

	public static void main(String[] args) {
		for(int i=0;i<args.length;i++)
		{
			System.out.println(args[i]);
		}

	}

}