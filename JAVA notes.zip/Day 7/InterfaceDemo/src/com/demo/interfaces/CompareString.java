package com.demo.interfaces;

public interface CompareString {
	String findMax(String x,String y); 
}
