
import java.util.Date;

public class TestPerson {

	public static void main(String[] args) {
		Person p=new Person(12,"Kishori","44444",new Date());
		//p.display();
		System.out.println(p);
		Person p1=new Person(13,"Rajan","33333",new Date());
		//p1.display();
		System.out.println(p1) ;   
		

	}

}
