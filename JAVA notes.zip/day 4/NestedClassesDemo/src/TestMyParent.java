
public class TestMyParent {
	public static void main(String[] args) {
		 MyParent p1=new MyParent();
		 
		 MyParent.MyChild ob= new  MyParent.MyChild();
	}

}
