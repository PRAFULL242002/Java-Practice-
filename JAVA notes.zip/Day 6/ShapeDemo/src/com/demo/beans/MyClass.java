package com.demo.beans;

public class MyClass {
	private int id;
	final String c;
	public MyClass() {
		super();
		c="Hello";
	}
	public MyClass(int id) {
		super();
		this.c="Welcome";
	}
	

}
